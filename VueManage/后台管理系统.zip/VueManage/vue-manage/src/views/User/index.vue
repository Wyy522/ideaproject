<template>
  <div class="manage">
    <el-dialog
      :title="operateType === 'add' ? '新增用户' : '更新用户'"
      :visible.sync="isShow"
    >
      <common-form
        :formLabel="opertateFormLabel"
        :form="operateForm"
        :inline="true"
        ref="form"
      ></common-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="isShow = false">取消</el-button>
        <el-button type="primary">确定</el-button>
      </div>
    </el-dialog>
    <div class="manage-header">
      <el-button type="primary">+新增</el-button>
      <common-form
        class="ips"
        :formLabel="FormLabel"
        :form="searchForm"
        :inline="true"
        ref="form"
      >
        <el-button type="primary"
          >搜索</el-button
        >
      </common-form>
    </div>
    <common-table
      :tableData="tableData"
      :tableLabel="tableLabel"
      :config="config"
      @changePage="getList"
      @edit="editUser"
      @del="delUser"
    ></common-table>
  </div>
</template>

<script>
import CommonTable from "../../components/CommenTable.vue";
import CommonForm from "../../components/COmmenForm.vue";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "User",
  components: { CommonForm, CommonTable },
  data() {
    return {
      isShow: false,
      operateType: "add",
      opertateFormLabel: [
        {
          model: "name",
          label: "姓名",
          type: "input",
        },
        {
          model: "age",
          label: "年龄",
          type: "input",
        },
        {
          model: "sex",
          label: "性别",
          type: "select",
          opts: [
            {
              label: "男",
              value: 1,
            },
            {
              label: "女",
              value: 0,
            },
          ],
        },
        {
          model: "birth",
          label: "出生日期",
          type: "date",
        },
        {
          model: "addr",
          label: "地址",
          type: "input",
        },
      ],
      operateForm: {
        name: "",
        addr: "",
        age: "",
        birth: "",
        sex: "",
      },
      FormLabel: [
        {
          model: "keyword",
          label: "",
          type: "input",
        },
      ],
      searchForm: {
        keyword: "",
      },
      tableData: [
        {
            name:"韦义烨",
            age:"21",
            birth:"2001-08-04",
            sexLabel:"男",
            addr:"江苏盐城"
        }
      ],
      tableLabel: [
        {
          prop: "name",
          label: "姓名",
        },
        {
          prop: "age",
          label: "年龄",
        },
        {
          prop: "sexLabel",
          label: "性别",
        },
        {
          prop: "birth",
          label: "出生日期",
          wdith: "200",
        },
        {
          prop: "addr",
          label: "地址",
          wdith: "320",
        },
      ],
      config: {
        total: 300,
        page: 1,
      },
    };
  },
  methods: {
    editUser(row) {
      this.operateType = "edit";
      this.isShow = true;
      this.operateForm = row;
    },
    delUser() {
      this.$confirm("此操作将永久删除该数据，是否继续？", "提示", {
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        type: "warning",
      })
    },
  },
  created() {
    this.getList();
  },
};
</script>

<style  socped lang="less">
.manage-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .ips {
    margin-top: 20px;
  }
}
</style>