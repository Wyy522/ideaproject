<template>
    <div>main</div>
</template>

<script>

export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name:'main',
    data(){
        return {}
    }
}
</script>
