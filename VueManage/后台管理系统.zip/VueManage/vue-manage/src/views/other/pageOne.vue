<template>
   <el-carousel indicator-position="outside">
    <el-carousel-item v-for="item in 4" :key="item">
      <img :src="item.url" />
      <div >{{item}}</div>
    </el-carousel-item>
  </el-carousel>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "page1",
  data() {
    return {
      ImgTwo: require("../../assets/images/1.png"),
      aaa:[
        {
            url:"../../assets/images/2.png",
            color:"#ffff"
      },{
            url:"../../assets/images/1.png",
            color:"#ccff"
      },
      ]
    };
  },
};
</script>

<style>
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 150px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}
</style>
