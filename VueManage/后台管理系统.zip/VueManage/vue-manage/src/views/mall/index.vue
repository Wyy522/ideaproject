<template>

  <el-table
    v-loading="loading"
    element-loading-text="拼命加载中"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(0, 0, 0, 0.8)"
    :data="tableData"
    style="width: 100%"
  >
    <el-table-column prop="date" label="日期" width="180"> </el-table-column>
    <el-table-column prop="name" label="姓名" width="180"> </el-table-column>
    <el-table-column prop="address" label="地址"> </el-table-column>
  </el-table>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "mall",
  data() {
    return {
      tableData: [
        {
          date: "2022-06-22",
          name: "韦义烨",
          address: "江苏盐城 ",
        },
        {
          date: "2022-06-22",
          name: "韦义烨",
          address: "江苏盐城 ",
        },
        {
          date: "2022-06-22",
          name: "韦义烨",
          address: "江苏盐城 ",
        },
      ],
      loading: true,
    };
  },
};
</script>
